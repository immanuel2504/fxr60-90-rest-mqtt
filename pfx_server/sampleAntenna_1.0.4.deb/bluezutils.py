# SPDX-License-Identifier: LGPL-2.1-or-later

import dbus
import time

SERVICE_NAME = "org.bluez"
ADAPTER_INTERFACE = SERVICE_NAME + ".Adapter1"
DEVICE_INTERFACE = SERVICE_NAME + ".Device1"

def get_managed_objects():
	bus = dbus.SystemBus()
	manager = dbus.Interface(bus.get_object("org.bluez", "/"),
				"org.freedesktop.DBus.ObjectManager")
	return manager.GetManagedObjects()

def find_adapter(pattern=None):
    while True:
        time.sleep(5)
        adapter = find_adapter_in_objects(get_managed_objects(), pattern)
        if adapter:
            return adapter
        
		

# def find_adapter_in_objects(objects, pattern=None):
# 	bus = dbus.SystemBus()
# 	for path, ifaces in objects.items():
# 		adapter = ifaces.get(ADAPTER_INTERFACE)
# 		if adapter is None:
# 			continue
# 		if not pattern or pattern == adapter["Address"] or \
# 							path.endswith(pattern):
# 			obj = bus.get_object(SERVICE_NAME, path)
# 			return dbus.Interface(obj, ADAPTER_INTERFACE)
# 	raise Exception("Bluetooth adapter not found")

def find_adapter_in_objects(objects, pattern=None):
    bus = dbus.SystemBus()
    while True:
        print("checking for adapter")
        for path, ifaces in objects.items():
            adapter = ifaces.get(ADAPTER_INTERFACE)
            if adapter is None:
                continue
            if not pattern or pattern == adapter["Address"] or \
                                path.endswith(pattern):
                obj = bus.get_object(SERVICE_NAME, path)
                print("Adapter found")
                return dbus.Interface(obj, ADAPTER_INTERFACE)
        # Optional delay to avoid a tight loop
        time.sleep(5)
        print("No matching adapter found, retrying...")
        # Update objects to get the latest managed objects
        objects = get_managed_objects()

def find_device(device_address, adapter_pattern=None):
	return find_device_in_objects(get_managed_objects(), device_address,
								adapter_pattern)

def find_device_in_objects(objects, device_address, adapter_pattern=None):
	bus = dbus.SystemBus()
	path_prefix = ""
	if adapter_pattern:
		adapter = find_adapter_in_objects(objects, adapter_pattern)
		path_prefix = adapter.object_path
	for path, ifaces in objects.items():
		device = ifaces.get(DEVICE_INTERFACE)
		if device is None:
			continue
		if (device["Address"] == device_address and
						path.startswith(path_prefix)):
			obj = bus.get_object(SERVICE_NAME, path)
			return dbus.Interface(obj, DEVICE_INTERFACE)

	raise Exception("Bluetooth device not found")
