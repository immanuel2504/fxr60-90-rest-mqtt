import logging
from gi.repository import Gio, GLib, GObject
import json
import subprocess

import pyziotc
import json
import time
import socket
import dbus

import bluezutils
import datetime
import struct

import http.client
import ssl
import logging.handlers

event_num = 0

hostname = socket.gethostname()

# ct stores current time
ct = datetime.datetime.now()


#z = pyziotc.Ziotc(pyziotc.CONNECT_TO_NOTHING)
z = pyziotc.Ziotc()


# Set up the logger to show in /var/log/message
logger = logging.getLogger('BLE_DA_APP')

logger.setLevel(logging.INFO)

# Set up the SysLogHandler to send log messages to syslog
syslog_handler = logging.handlers.SysLogHandler(address='/dev/log')
formatter = logging.Formatter('%(name)s: %(levelname)s %(message)s')
syslog_handler.setFormatter(formatter)

# Add the handler to the logger
logger.addHandler(syslog_handler)



    

# DBus Information
bus_type = Gio.BusType.SYSTEM
BLUEZ_NAME = "org.bluez"
ADAPTER_PATH = "/org/bluez/hci0"
PROP_IFACE = "org.freedesktop.DBus.Properties"
ADAPTER_IFACE = "org.bluez.Adapter1"
DEVICE_IFACE = "org.bluez.Device1"


# logging.basicConfig(level=logging.DEBUG)

# logger = logging.getLogger("scan_app")


# webhook url
url = "https://webhook.site/4bd420d2-a9ce-4697-bff0-fb7e11b3352f"


def new_msg_callback(msg_type, msg_in):
    if msg_type == pyziotc.MSG_IN_JSON:
        msg_in_json = json.loads(msg_in)
        data = bytearray(json.dumps(msg_in_json, default=str), "utf-8")
        z.send_next_msg(pyziotc.MSG_OUT_DATA, data)


z.reg_new_msg_callback(new_msg_callback)


def post_json_with_curl(json_data, url):
    # Convert JSON data to a string
    json_string = json.dumps(json_data, indent=4)

    # Prepare the curl command
    curl_command = [
        "curl",
        "-X",
        "POST",
        "-H",
        "Content-Type: application/json",
        "-d",
        json_string,
        url,
    ]

    # Call curl using subprocess
    try:
        output = subprocess.check_output(curl_command, stderr=subprocess.STDOUT)
        print("Sent data to HTTP server")
        # print(output.decode())
    except subprocess.CalledProcessError as e:
        print("Error executing curl command:", e.output.decode())


def send_to_data_channel(json_data):
    # led_red_msg = bytearray(json.dumps({"type":"LED","color":"RED","time":ct},default=str), "utf-8")
    ble_data = bytearray(
        json.dumps(
            {
                "data": json_data,
                "timestamp": ct,
                "type": "BLE_DATA",
                "hostName": hostname,
            },
            indent=4,
            default=str,
        ),
        "utf-8",
    )
    z.send_next_msg(pyziotc.MSG_OUT_DATA, ble_data)


def create_variant(py_data):
    """
    convert python native data types to D-Bus variant types by looking up
    their type expected for that key.
    """
    type_lookup = {
        "Address": "s",
        "AddressType": "s",
        "Name": "s",
        "Icon": "s",
        "Class": "u",
        "Appearance": "q",
        "Alias": "s",
        "Paired": "b",
        "Trusted": "b",
        "Blocked": "b",
        "LegacyPairing": "b",
        "RSSI": "n",
        "Connected": "b",
        "UUIDs": "as",
        "Adapter": "o",
        "ManufacturerData": "a{qay}",
        "ServiceData": "a{say}",
        "TxPower": "n",
        "ServicesResolved": "b",
        "WakeAllowed": "b",
        "Modalias": "s",
        "AdvertisingFlags": "ay",
        "AdvertisingData": "a{yay}",
        "Powered": "b",
        "Discoverable": "b",
        "Pairable": "b",
        "PairableTimeout": "u",
        "DiscoverableTimeout": "u",
        "Discovering": "b",
        "Roles": "as",
        "ExperimentalFeatures": "as",
    }
    if py_data is None:
        return GLib.Variant("a{sv}", {})
    for k, v in py_data.items():
        py_data[k] = GLib.Variant(type_lookup[k], v)
    return GLib.Variant("a{sv}", py_data)


class BluezObjectManager(GObject.GObject):
    __gsignals__ = {
        "adapter-added": (
            GObject.SignalFlags.NO_HOOKS,
            None,
            (str, GObject.TYPE_VARIANT),
        ),
        "adapter-removed": (GObject.SignalFlags.NO_HOOKS, None, (str,)),
        "device-added": (
            GObject.SignalFlags.NO_HOOKS,
            None,
            (str, GObject.TYPE_VARIANT),
        ),
        "device-removed": (GObject.SignalFlags.NO_HOOKS, None, (str,)),
    }

    def __init__(self) -> None:
        super().__init__()
        self._object_manager = Gio.DBusObjectManagerClient.new_for_bus_sync(
            bus_type,
            Gio.DBusObjectManagerClientFlags.DO_NOT_AUTO_START,
            BLUEZ_NAME,
            "/",
            None,
            None,
            None,
        )

        self._object_manager.connect("object-added", self._on_object_added)
        self._object_manager.connect("object-removed", self._on_object_removed)

    def _on_object_added(
        self, _object_manager: Gio.DBusObjectManager, dbus_object: Gio.DBusObject
    ) -> None:
        object_path = dbus_object.get_object_path()
        ifaces = [iface.get_interface_name() for iface in dbus_object.get_interfaces()]
        if ADAPTER_IFACE in ifaces:
            prop_proxy = dbus_object.get_interface(PROP_IFACE)
            adapter_props = prop_proxy.GetAll("(s)", ADAPTER_IFACE)
            # logger.debug('adapter-added %s', object_path, adapter_props)
            logger.debug("adapter-added %s", object_path)
            self.emit("adapter-added", object_path, adapter_props)
        elif DEVICE_IFACE in ifaces:
            prop_proxy = dbus_object.get_interface(PROP_IFACE)
            dev_props = prop_proxy.GetAll("(s)", DEVICE_IFACE)
            # logger.debug('device-added %s : %s', object_path, dev_props)
            logger.debug("device-added %s ", object_path)
            self.emit("device-added", object_path, create_variant(dev_props))

    def _on_object_removed(
        self, _object_manager: Gio.DBusObjectManager, dbus_object: Gio.DBusObject
    ) -> None:
        object_path = dbus_object.get_object_path()
        ifaces = [iface.get_interface_name() for iface in dbus_object.get_interfaces()]
        if ADAPTER_IFACE in ifaces:
            logger.debug("adapter-removed %s : %s", object_path)
            self.emit("adapter-removed", object_path)
        elif DEVICE_IFACE in ifaces:
            logger.debug("device-removed: %s", object_path)
            self.emit("device-removed", object_path)


def bluez_proxy(object_path, interface):
    """Return a BlueZ proxy object for the given D-Bus information"""
    return Gio.DBusProxy.new_for_bus_sync(
        bus_type=bus_type,
        flags=Gio.DBusProxyFlags.NONE,
        info=None,
        name=BLUEZ_NAME,
        object_path=object_path,
        interface_name=interface,
        cancellable=None,
    )


def new_device_hndlr(
    proxy: BluezObjectManager, object_path: str, device_props: GObject.TYPE_VARIANT
) -> None:
    """Event handler for New device has been detected with scan"""
    
    #print (device_props )
    props = device_props.unpack()

    
   # string_data = props.get('ManufacturerData').decode('utf-8')
    #print(string_data)
    #print("\n\n")
    #print(props["ManufacturerData"])
    
    if ( "ManufacturerData" in props):
        mfg_data = props["ManufacturerData"]

        #if ( list(mfg_data.keys())[0] == 700):
        if ( False):
    
            bytes_object = bytes(mfg_data[list(mfg_data.keys())[0]])
    
            print(bytes_object)
    
            print(bytes_object.hex())
    
    
            header = bytes_object[:2]
            payload = bytes_object[2:-1]
            footer = bytes_object[-1:]
    
    
            print(f"Header: {header.hex()}")
            print(f"Payload: {payload.decode('ascii')}")  
            print(f"Footer: {footer.hex()}")
    
            decoded_string = bytes_object.decode('latin1', errors='ignore')

        
            binary_data_json = {
                "header": header.hex(),
                "payload": payload.decode('ascii'),
                "footer": footer.hex()
            }
    
            print(binary_data_json)
            props["ManufacturerDataASCIIString"] = binary_data_json
        
    

        hex_data = {f"0x{key:02x}": [f"0x{num:02x}" for num in value] for key, value in mfg_data.items()}
    
        props["ManufacturerDataHex"] = hex_data

    
        hex_data_str = {key.to_bytes(2, byteorder='little').hex(): [num.to_bytes(1, byteorder='big').hex() for num in value] for key, value in mfg_data.items()}
    
        hex_data_str_conc = ''.join(str(key) + ''.join(value) for key, value in hex_data_str.items())
    
        props["ManufacturerDataHexString"] = hex_data_str_conc
        
        bytes_object = bytes(mfg_data[list(mfg_data.keys())[0]])
        
        # print(bytes_object)
    
        # print(bytes_object.hex())
        
        decoded_string = bytes_object.decode('latin1', errors='ignore')
        
        binary_data_json = {
                "raw":decoded_string,
                "hexASCII":bytes_object.hex(),
                
            }
        
        # print(decoded_string)
        
        # print(binary_data_json)
        
        props["ManufacturerDataRaw"] = binary_data_json
    

    
    json_str = json.dumps(props, indent=4)
    
    #
    # print data test
    #
    #print(f'\n\n------------------------------')
    #print(f'\n\nData\n'+json_str)
    # Call the function with JSON data and URL
    # post_json_with_curl(props, url)
    # Send data to IOT
    send_to_data_channel(props)
    # logger.debug('\n\n :- New Device Handler: %s : %s', object_path, props)
    address = props.get("Address")
    if address:
        print("---------------------------------------")
        global event_num
        event_num = event_num + 1
        print("event num" + str(event_num))
        print(
            f"\n\nDevice with address {address} found. "
            f"\n\nRemoving from BlueZ cache"
        )
    # adapter.RemoveDevice('(o)', GLib.Variant.new_object_path(object_path))
    #adapter.RemoveDevice("(o)", object_path)
    adapter.RemoveDevice(object_path)


def stop_scan():
    """Stop scanning for new devices and quit event loop"""
    logger.info("Stopping Discovery")
    adapter.StopDiscovery()
    mainloop.quit()
    return False

def start_rfid_inv():
    conn = http.client.HTTPSConnection("127.0.0.1",context = ssl._create_unverified_context())
    payload = {}
    headers = {
    'Content-Type': 'application/json; charset=utf-8'
    }
    conn.request("PUT", "/cloud/start", payload, headers)
    res = conn.getresponse()
    data = res.read()
    #print(data.decode("utf-8"))
    logger.info("Starting RFID Inventory")
    
    
    
def set_data_to_RG():
    conn = http.client.HTTPSConnection("127.0.0.1",context = ssl._create_unverified_context())
    payload = {}
    headers = {
    'Content-Type': 'application/json; charset=utf-8'
    }
    conn.request("PUT", "/cloud/setdataToRG", payload, headers)
    res = conn.getresponse()
    data = res.read()
    #print(data.decode("utf-8"))
    logger.info("Setting data to RG")




if __name__ == "__main__":
    logger.info('Starting BLE DA APP')
    
    #auto start RFID Inv
    start_rfid_inv()
    time.sleep(1)
    set_data_to_RG()
    # setup dbus
    mngr = BluezObjectManager()
    #adapter = bluez_proxy(ADAPTER_PATH, ADAPTER_IFACE)
    # Link device-added event to callback function

    adapter = bluezutils.find_adapter()
    mngr.connect("device-added", new_device_hndlr)
    # Start discovering (scanning) for devices
    scan_filter = dict()
    scan_filter.update({"DuplicateData": False})
    scan_filter.update({"Transport": "le"})  #default is "auto" , others :-  "bredr" , "le"

    
    while True:
        try:
            adapter.SetDiscoveryFilter(scan_filter)
            print("Discovery filter set successfully.")
            logger.info('Discovery filter set successfully.')
            break
        except dbus.DBusException as e:
            print("Failed to set discovery filter, retrying...", e)
            logger.info('Failed to set discovery filter, retrying.')
            time.sleep(5)
    
    print("wait 10 sec")
    logger.info("wait 10 sec.")
    time.sleep(10)
    print("starting discovery")      
    logger.info("starting discovery.") 
    adapter.StartDiscovery()

    # Enable eventloop for notifications
    mainloop = GLib.MainLoop()
    # Create a timed event to call the stop_scan function
    # GLib.timeout_add_seconds(interval=60, function=stop_scan)

    try:
        mainloop.run()
    except KeyboardInterrupt:
        mainloop.quit()
        adapter.StopDiscovery()
        logger.info("Stopping Discovery")
        logger.info("Exiting...")
        """Stop scanning for new devices on keyboard interrupt"""
        
