EXECUTABLE_NAME=sampleAntenna

echo "starting python sample DA application"

python3 /apps/${EXECUTABLE_NAME}.py 

echo "done!"
wait
