import json
import asyncio
import pyziotc
import time
import datetime
import http.client
import ssl
from http.client import HTTPConnection
from base64 import b64encode

passthru_count = 0
current_gpi_state = False

def passthru_callback(msg_in):
    global passthru_count
    global current_gpi_state
    global z
    passthru_count = passthru_count +1
    c=HTTPConnection("127.0.0.1")
    c.request('GET', '/cloud/status')
    res = c.getresponse()
    data = res.read()
    print(data)
    try:
        z.send_next_msg(pyziotc.MSG_OUT_CTRL,(data, "utf-8"))
    except Exception as e:
        print("Exception ")

    response = bytearray(("Got Message # " + str(passthru_count) + " " + msg_in).encode('utf-8'))

    return response

def new_msg_callback(msg_type, msg_in):
    print(msg_in)
    print(msg_type)
    global z
    #msg_in_json = json.loads(msg_in.decode('utf-8'))
    #tag_id = msg_in_json["data"]["idHex"]
    cat = "data from python DA to mqtt "+msg_in
    cat1 = "data from python DA to http"+msg_in
    z.send_next_msg(pyziotc.MSG_OUT_DATA,bytearray("data from DA"+msg_in, "utf-8"))
    #z.send_next_msg(pyziotc.MSG_OUT_DATA,bytearray(cat1, "utf-8"))
    #z.send_next_msg(pyziotc.MSG_OUT_CTRL,bytearray("mydata :"+msg_in, "utf-8"))
    if msg_type == pyziotc.MSG_IN_GPI:
        z.send_next_msg(pyziotc.MSG_OUT_CTRL,bytearray("mydata :"+msg_in, "utf-8"))

z = pyziotc.Ziotc()
version_msg = bytearray(z.version(), "utf-8")
z.send_next_msg(pyziotc.MSG_OUT_CTRL,version_msg)

z.enableGPIEvents()
z.reg_pass_through_callback(passthru_callback)
z.reg_new_msg_callback(new_msg_callback)

gpo_green_msg = bytearray(json.dumps({"type":"LED","color":"GREEN","led":3}), "utf-8")
gpo_yellow_msg = bytearray(json.dumps({"type":"LED","color":"AMBER","led":3}), "utf-8")
gpo_red_msg = bytearray(json.dumps({"type":"LED","color":"RED","led":3}), "utf-8")

c = 0
d=1

while True:
    time.sleep(10)
    time_msg = bytearray(datetime.datetime.now().isoformat(), "utf-8")
    #z.send_next_msg(pyziotc.MSG_OUT_CTRL,time_msg)
    #z.send_next_msg(pyziotc.MSG_OUT_CTRL,bytearray(str(d), "utf-8"))
    print(d)
    d=d+1

    if c == 0:
        print("green")
        z.send_next_msg(pyziotc.MSG_OUT_GPO,gpo_green_msg)
        c = 1
    elif c == 1:
        print("yellow")
        z.send_next_msg(pyziotc.MSG_OUT_GPO,gpo_yellow_msg)
        c = 2
    elif c == 2:
        print("red")
        z.send_next_msg(pyziotc.MSG_OUT_GPO,gpo_red_msg)
        c = 0

z.send_next_msg(pyziotc.MSG_OUT_GPO,gpo_msg)


del(z)
