import time
import pyziotc
import json
prefix = 1

def new_msg_callback(msg_type, msg_in):

    global z

    if msg_type == pyziotc.MSG_IN_JSON:

        msg_in_json = json.loads(msg_in)

        tag_id_hex = msg_in_json["data"]["antenna"]

        if tag_id_hex == prefix:

            cat1 = "Message From Python DA App: " + msg_in

            print(f"sending message {msg_in}")

            z.send_next_msg(pyziotc.MSG_OUT_DATA, bytearray(cat1, "utf-8"));

z = pyziotc.Ziotc()


z.reg_new_msg_callback(new_msg_callback)


while True:

    time.sleep(1)
