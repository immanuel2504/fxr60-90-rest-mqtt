import requests
import time

def make_api_request():
    try:
        response = requests.get(
            "https://127.0.0.1/cloud/status",
            verify=False  # Set to False for self-signed certificates; use caution in production
        )
        response.raise_for_status()  # Raise an error for bad responses
        data = response.json()  # Parse JSON response
        version = data.get('version')  # Assuming the version info is in the 'version' field
        runtime = data.get('runtime')  # Assuming the runtime info is in the 'runtime' field
        print(f"Version: {version}, Runtime: {runtime}")
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")

def request_api_regularly():
    interval_seconds = 55555Set the interval for every 2 seconds
    while True:
        make_api_request()
        time.sleep(interval_seconds)

request_api_regularly()

