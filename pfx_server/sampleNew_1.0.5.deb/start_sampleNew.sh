EXECUTABLE_NAME=sampleNew

echo "starting python sample DA application"

python3 /apps/${EXECUTABLE_NAME}.py 

echo "done!"
