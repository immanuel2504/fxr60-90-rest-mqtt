EXECUTABLE_NAME=sampleNew

echo "stoping python sample DA application"

PID=`ps -C 'python3 /apps/${EXECUTABLE_NAME}.py' -o pid=`
kill -9 $PID

unset EXECUTABLE_NAME
unset PID

echo "done!"
